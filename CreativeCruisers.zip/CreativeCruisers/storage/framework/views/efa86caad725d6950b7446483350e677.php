<?php
if (isset($_POST['submitted'])){
  require_once('connectdb.php');
	
  $username=isset($_POST['username'])?$_POST['username']:false;
  $password=isset($_POST['password'])?password_hash($_POST['password'],PASSWORD_DEFAULT):false;
  $email = isset($_POST['email'])?$_POST['email']:false;
      	if(empty($username)) {
        	$usernameErr = "username is required";
        }
		if(empty($_POST['password'])) {
        	$passwordErr = "password is required";
        }
		if(empty($email)) {
        	$emailErr = "email is required";
        }
	else{
 try{
	$stat=$conn->prepare("insert into user values(default,?,?,?)");
	$stat->execute(array($username, $password, $email));
 	header("Location: /index.php");
 	
	
 }
 catch (PDOexception $ex){
	echo "Sorry, a database error occurred! <br>";
	echo "Error details: <em>". $ex->getMessage()."</em>";
 }
 }


 
}






?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Document</title>
    <style>
        .error {
            color: red;
        }

        body {
            padding-bottom: 200px;

            form {
                position: relative;
                margin-top: 30px;
            }
        }
		.card{
			  margin: auto;
  			  width: 50%;
  			  border: 3px solid black;
  			  padding: 5px;
        }
    </style>
</head>

<body>
<div class="d-flex p-2">
<div class="card" style="width: 18rem;">
<div class="card-body">
    <h2>Register</h2>
  <form method = "post" action="register.php">
	Username: <input type="text" name="username" /><br>
	Password: <input type="password" name="password" /><br><br>
    Email: <input type="text" name="email" /><br><br>

    <button type="submit" name="submitted" value="TRUE" class="btn btn-primary">Register</button>
    <button type="reset" class="btn btn-primary">Clear</button>
  </form>  
  <p> Already a user? <a href="index.php">Log in</a>  </p>
</div>
</div>
</div>

</body>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CreativeCruisers/CreativeCruisers/resources/views/register.blade.php ENDPATH**/ ?>